yajsw-alpha-12.00

    * Bug: MacOsX - thanks for the patch
    * Bug: WrappedRuntimeProcess: sort arguments according to configuration keys
    * Change: update to latest jars: commons-collections-3.2.1, commons-configuration-1.10, jna-4.1.0, netty-all-5.0.0.Alpha2-SNAPSHOT, groovy-all-2.3.0-beta-2
    * Change: move groovy dependency to lib/extended
    * Change: do not add passwords to command line of processes or services
    * Change: minor logging changes  and other minor changes.
    * Change: license change - see documentation
    * Change: regex in configuration files: switched from jrexx to dk.brics.automaton. moved jar to lib/extended. functionality is thus optional. NOTE: regex syntax may have changed
