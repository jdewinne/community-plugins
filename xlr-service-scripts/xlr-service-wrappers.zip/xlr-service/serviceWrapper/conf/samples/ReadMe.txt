Here some configuration samples for some standard applications

- Derby as server
- Jetty
- Tomcat
- Eclipse Equinox OSGI

Samples for:

- Wrapping a groovy script
- Wrapping a jar file (eg for programs which  are run as "java -jar myapp.jar"